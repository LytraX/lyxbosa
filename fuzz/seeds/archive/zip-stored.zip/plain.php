<?php
// an ordinary file
echo 'hello';
