<?php define('DB_PASSWORD','x'); ?>
